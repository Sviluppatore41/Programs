# How to publish

Push the release's tag before running this.

```
sh ./build_and_release.sh $GITHUB_TOKEN [$CURSEFORGE_TOKEN] [$MODRINTH_TOKEN]
```
