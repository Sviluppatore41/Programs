Requires [BaublesExpanded](https://github.com/GTNewHorizons/Baubles-Expanded)

-------------------

Decompiled thaumcraft 4(I'm nor sure if it's illegal,sorry [Azanor](https://github.com/Azanor/thaumcraft-beta)) and added parameterized types.
I need lots of cleaning.

maybe it's better to rewrite these all.

most of Hodgepodge and TC4Tweaks modification are applied.Don't use with TC4Tweaks.

UnicodeFontFixer is still recommended because i don't know what they actually did.

-------------------

going to migrate to 1.20.1,but needs a far way.(api migration almost finished,thx to chatGPT i can know apis and migrations fast.)