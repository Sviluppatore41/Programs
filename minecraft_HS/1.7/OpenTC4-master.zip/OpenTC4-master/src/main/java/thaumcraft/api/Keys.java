package thaumcraft.api;

import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;

public class Keys {
    public static final KeyBinding keyF = new KeyBinding("Change Wand Focus", Keyboard.KEY_NONE, "Thaumcraft");
    public static final KeyBinding keyH = new KeyBinding("Activate Hover Harness", Keyboard.KEY_NONE, "Thaumcraft");
    public static final KeyBinding keyG = new KeyBinding("Misc Wand Toggle", Keyboard.KEY_NONE, "Thaumcraft");
}
