package thaumcraft.api;


/**
 * 
 * @author Azanor
 * 
 * Interface used to identify scribing tool items used in research table
 *
 */

public interface IScribeTools {
	
}
